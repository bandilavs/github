<?php
include "connect.php";
if ($connection) {
    echo "<h3 style='color:green'>Connection Established</h3>";
}else{
    echo "error".mysqli_error($connection);
}
$user=$_POST['user'];
$password=$_POST['password'];
$sql="SELECT * FROM ram WHERE username='$user' AND password='$password';";
$res=mysqli_query($connection,$sql);
$data=mysqli_fetch_assoc($res);
if($data){
    echo "logged in";
    header('Location:webpage.html');
}
else{
	echo"no data found register here";
	header('Location:popup.html');
}


?>
