<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "formin";
$connection= new mysqli($serverName, $userName, $password, $databaseName);
?>
