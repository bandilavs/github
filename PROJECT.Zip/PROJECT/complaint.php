<?php 
	include "conn3.php";
	if($connection){
		echo "connection Establisted"."<br>";
	}
	else{
		echo "Error : "."<br>";
		}
$comp= $_POST["compl"];
$query="CREATE TABLE complai(complain VARCHAR(200));";
if(new mysqli($connection, $query))
{
    echo "<h4 style='color:green'>Table Created </h4>";
}
else
{
    echo "<h4 style='color:red'>Table not Created . ".mysqli_error($connection)."</h4>";
}
$query1 = "INSERT INTO complai VALUES('".$comp."');";
if(new mysqli($connection,$query1)){

    echo "<h4 style='color:grey'>Record Inserted</h4><br>";
	header('Location:complaint_alert.html');
}
else			
{
    echo "<h4 style='color:blue'>Record Not Inserted</h4><br>";
}

?>


	
