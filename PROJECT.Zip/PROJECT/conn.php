<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "formout";
$connection = new mysqli($serverName, $userName, $password, $databaseName);
?>
