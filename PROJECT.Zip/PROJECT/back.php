<?php
    header("Location:webpage.html");
?>