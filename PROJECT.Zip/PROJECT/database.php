<?php
include "connect.php";
if ($connection) {
    echo "<h3 style='color:green'>Connection Established</h3>";
}else{
    echo "error".mysqli_error($connection);
}


$name= $_POST['uname'];
$password= $_POST['pwd'];
$confirmpass= $_POST['cpwd'];
$mobile= $_POST['mobile'];
$gmail= $_POST['mail'];
$query = "CREATE TABLE sam (username VARCHAR(20) NOT NULL, password CHAR(15) NOT NULL,confirmpassword VARCHAR(15) NOT NULL,mobileno INT NOT NULL,gmail VARCHAR(20) NOT NULL);";
if(new mysqli($connection, $query))
{
    echo "<h4 style='color:green'>Table Created </h4>";
}
else
{
    echo "<h4 style='color:red'>Table not Created . ".mysqli_error($connection)."</h4>";
}

$query1 = "INSERT INTO sam VALUES('$name','$password','$confirmpass',$mobile,'$gmail')VALUES ('teju','sltt@123','sltt@123',9014847480,'tej@gamil.com')";
if(new mysqli($connection,$query1)){

    echo "<h4 style='color:grey'>Record Inserted</h4><br>";
    header('Location:personal.html');
}
else			
{
    echo "<h4 style='color:blue'>Record Not Inserted</h4><br>";
    echo "errror:".mysqli_error($connection);
}

?>
