<?php
include "conn.php";
if ($connection) {
    echo "<h3 style='color:green'>Connection Established</h3>";
}else{
    echo "error".mysqli_error($connection);
}
session_start();
$name = $_GET['sname'];
$idno = $_GET['idno'];
$year = $_GET['year'];
$branch = $_GET['branch'];
$date = $_GET['date'];
$reason = $_GET['reason'];
$_SESSION['sname']=$name;
$_SESSION['idno']=$idno;
$_SESSION['year']=$year;
$_SESSION['branch']=$branch;
$_SESSION['date']=$date;
$_SESSION['reason']=$reason;

$query = "CREATE TABLE formout (Studentname VARCHAR(20) NOT NULL, IDNO CHAR(15) NOT NULL,Year CHAR(5) NOT NULL,Branch CHAR(20),Date VARCHAR(10) NOT NULL,REASON VARCHAR(200) NOT NULL);";
if(new mysqli($connection, $query))
{
    echo "<h4 style='color:green'>Table Created </h4>";
}
else
{
    echo "<h4 style='color:red'>Table not Created . ".mysqli_error($connection)."</h4>";
}

$query1 = "INSERT INTO formout VALUES('$name','$idno','$year','$branch','$date','$reason');";
if(new mysqli($connection,$query1)){

    echo "<h4 style='color:grey'>Record Inserted</h4><br>";
    header('Location:popup2.html');
}
else			
{
    echo "<h4 style='color:blue'>Record Not Inserted . ".mysqli_error($connection)."</h4>";
}
?>
