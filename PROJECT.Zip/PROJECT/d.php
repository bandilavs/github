<?php
$file='userdetails.txt';
header("Content-Disposition: attachment; filename=".$file);
readfile($file);
?>
