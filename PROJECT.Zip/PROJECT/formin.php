<?php
include "conn2.php";
if ($connection) {
    echo "<h3 style='color:green'>Connection Established</h3>";
}else{
    echo "error".mysqli_error($connection);
}

$name = $_POST['sname'];
$idno = $_POST['idno'];
$year = $_POST['year'];
$branch = $_POST['branch'];
$date = $_POST['date'];
if(new mysqli($connection, $query))
{
    echo "<h4 style='color:green'>Table Created </h4>";
}
else
{
    echo "<h4 style='color:red'>Table not Created . ".mysqli_error($connection)."</h4>";
}

$query1 = "INSERT INTO formin VALUES('$name','$idno','$year','$branch','$date');";
if(new mysqli($connection,$query1)){

    echo "<h4 style='color:grey'>Record Inserted</h4><br>";
     header('Location:popup3.html');
}
else			
{
    echo "<h4 style='color:blue'>Record Not Inserted . ".mysqli_error($connection)."</h4>";
}

?>
