<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "registered";
$connection = new mysqli($serverName, $userName, $password, $databaseName);
?>
