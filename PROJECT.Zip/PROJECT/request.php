
<?php
session_start();
$file=fopen("userdetails.txt",'w');
	fwrite($file,"\n RAJIV GANDHI UNIVERSITY OF KNOWLWDGE AND TECHNOLOGY \n \n STUDENT OUTPASS \n \n");
$name=$_SESSION['sname'];
	fwrite($file,"NAME:".$name."\n \n");
$idno=$_SESSION['idno'];
	fwrite($file,"ID NUMBER:".$idno."\n \n");
$year=$_SESSION['year'];
	fwrite($file,"YEAR:".$year."\n \n");
$branch=$_SESSION['branch'];
	fwrite($file,"BRANCH:".$branch."\n \n");
$date=$_SESSION['date'];
	fwrite($file,"DATE:".$date."\n \n");
$msg=$_SESSION['reason'];
	fwrite($file,"REASON:".$msg);
	fwrite($file,"\n STATUS:STUDENT OUTPASS GRANTED \n \n SIGNATURE OF THE WARDEN:NAGARJUNA");
	echo "<button><a href='d.php?file=userdetails.txt'>download here</a><button>";
	echo "<br>";
	echo "<button><a href='back.php?'>back</a></button>";
?>
