<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "complaint_box";
$connection = new mysqli($serverName, $userName, $password, $databaseName);
?>
